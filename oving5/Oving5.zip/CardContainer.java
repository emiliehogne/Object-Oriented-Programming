package oving5;

public interface CardContainer {

    public int getCardCount();

    public Card getCard(int n);

}
