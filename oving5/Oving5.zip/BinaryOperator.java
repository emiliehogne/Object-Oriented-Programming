package oving5;

public class BinaryOperator {

}
