package oving5;

public interface Named {

    public void setGivenName(String s);

    public String getGivenName();

    public void setFamilyName(String s);

    public String getFamilyName();

    public void setFullName(String s);

    public String getFullName();

}
